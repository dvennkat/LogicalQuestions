//
//  Model.swift
//  MvvmSwiftUI
//
//  Created by Venkata Reddy Dubbakula on 21/11/24.
//

import Foundation

struct Model: Identifiable {
    var id: Int
    var name: String
    var surName: String
}
