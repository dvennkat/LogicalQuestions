//
//  ViewModel.swift
//  MvvmSwiftUI
//
//  Created by Venkata Reddy Dubbakula on 21/11/24.
//

import Foundation

class ViewModel: ObservableObject {
    //@Published var user = [Model]()
    @Published var user: [Model] = []
    
    func loadUsers() {
        user.append(Model(id: 1, name: "venkat", surName: "dubbakula"))
        user.append(Model(id: 2, name: "venkat reddy", surName: "Dubbaka"))
        user.append(Model(id: 3, name: "shiva", surName: "reddy"))
    }
}
