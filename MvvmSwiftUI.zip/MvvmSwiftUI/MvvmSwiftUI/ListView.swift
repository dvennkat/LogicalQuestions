//
//  ListView.swift
//  MvvmSwiftUI
//
//  Created by Venkata Reddy Dubbakula on 21/11/24.
//

import SwiftUI

struct ListView: View {
    @ObservedObject var users = ViewModel()

    var body: some View {

        List(users.user) { user in
            VStack(alignment: .leading) {
                Text(user.name)
                Text(user.surName)
            }
        }.onAppear() {
            users.loadUsers()
        }
    }
}


#Preview {
    ListView()
}
