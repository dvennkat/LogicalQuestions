//
//  MvvmSwiftUIApp.swift
//  MvvmSwiftUI
//
//  Created by Venkata Reddy Dubbakula on 21/11/24.
//

import SwiftUI

@main
struct MvvmSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ListView()
        }
    }
}
