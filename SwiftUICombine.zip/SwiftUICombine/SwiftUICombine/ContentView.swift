//
//  ContentView.swift
//  SwiftUICombine
//
//  Created by Venkata Reddy Dubbakula on 19/11/24.
//

import SwiftUI
import Combine

struct ContentView: View {
    var subject = CurrentValueSubject<String, Never>("")
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
            Button(action: {
                subject.send("venkat")
            }, label: {
                Text("click")
            })
        }
        .padding()
        .onAppear() {
            print("venkat")
            subject.sink { value in
                print("value \(value)")
            }
        }
    }
}

#Preview {
    ContentView()
}
