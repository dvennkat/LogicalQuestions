//
//  SwiftUICombineApp.swift
//  SwiftUICombine
//
//  Created by Venkata Reddy Dubbakula on 19/11/24.
//

import SwiftUI

@main
struct SwiftUICombineApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
