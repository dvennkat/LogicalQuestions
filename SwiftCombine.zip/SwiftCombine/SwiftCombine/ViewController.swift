//
//  ViewController.swift
//  SwiftCombine
//
//  Created by Venkata Reddy Dubbakula on 19/11/24.
//

import UIKit
import Combine
class ViewController: UIViewController {
    let currentUserId = CurrentValueSubject<Int, Never>(1000)
    let subject1 = PassthroughSubject<Int, Never>()
    let subject2 = PassthroughSubject<String, Never>()
    var subscriptions = Set<AnyCancellable>()

    @IBAction func Click(_ sender: UIButton) {
        currentUserId.send(3)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let sub = currentUserId.sink { completion in
            print("completion", completion)
        } receiveValue: { value in
            print("value", value)
        }
        .store(in: &subscriptions)
        
        currentUserId.value = 1
        currentUserId.value = 2
        
        subject1.combineLatest(subject2)
            .sink { _ in
                
            } receiveValue: { (intValue, StringValue) in
                print("intValue \(intValue) StringValue \(StringValue) ")
            }
            .store(in: &subscriptions)
        subject1.send(1)
        subject1.send(2)
        //subject2.send("A")
        //subject2.send("B")
        subject1.send(3)
        subject2.send("C")


    }


}

