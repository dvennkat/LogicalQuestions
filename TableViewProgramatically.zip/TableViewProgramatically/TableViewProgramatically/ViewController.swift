//
//  ViewController.swift
//  TableViewProgramatically
//
//  Created by Venkata Reddy Dubbakula on 10/12/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    var tableView:UITableView = {
        let tableView = UITableView()
        tableView.backgroundColor = .red
        return tableView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.addSubview(tableView)
        tableView.register(CustomTableViewCell.self, forCellReuseIdentifier: "CustomTableViewCell")

        tableView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate(
            [tableView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 0),
             tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
             tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 15),
             tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 15)
            ])
        tableView.dataSource = self
        tableView.delegate = self
    }


}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomTableViewCell", for: indexPath) as! CustomTableViewCell
        cell.label.text = "name 1 \(indexPath.row)"
        cell.label2.text = "name 2 \(indexPath.row)"
        
        if indexPath.row == 1 {
            cell.label.text = ""
            cell.label2.text = ""
            cell.activity.startAnimating()
        }
        
        cell.stopCallBack = {  vlue in
            if vlue {
                cell.label.text = "name 1 \(indexPath.row)"
                cell.label2.text = "name 2 \(indexPath.row)"
                cell.activity.stopAnimating()
            }
        }
        cell.updateData1(row: indexPath.row)
//        cell.updateData(row: indexPath.row) {
//            cell.label.text = "name 1 \(indexPath.row)"
//            cell.label2.text = "name 2 \(indexPath.row)"
//            cell.activity.stopAnimating()
//        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        60
    }
    
    
}

class CustomTableViewCell: UITableViewCell {
    
    let label: UILabel = {
        let label = UILabel()
        return label
    }()
    let label2: UILabel = {
        let label = UILabel()
        return label
    }()
    let activity: UIActivityIndicatorView = {
        let activity = UIActivityIndicatorView(style: .large)
        return activity
    }()
    
    var stopCallBack: (Bool) ->() = {_ in }
    
//    func updateData(row: Int,  completion: @escaping () ->()) {
//        
//        if row == 1 {
//            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
//                completion()
//            }
//        }
//        
//    }
//    
    func updateData1(row: Int) {
        if row == 1 {
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                self.stopCallBack(true)
            }
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.contentView.addSubview(label)
        self.contentView.addSubview(label2)
        self.contentView.addSubview(activity)
        self.label.translatesAutoresizingMaskIntoConstraints = false
        self.label2.translatesAutoresizingMaskIntoConstraints = false
        self.activity.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            self.label.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: 10),
            self.label.centerYAnchor.constraint(equalTo: self.contentView.centerYAnchor, constant: 10),
            self.label.heightAnchor.constraint(equalToConstant: 15.0),
            self.label.trailingAnchor.constraint(equalTo: self.contentView.centerXAnchor, constant: 10),
            
            self.label2.leadingAnchor.constraint(equalTo: self.label.trailingAnchor, constant: 5),
            self.label2.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: 10),
            self.label2.heightAnchor.constraint(equalToConstant: 15.0),
            self.label2.centerYAnchor.constraint(equalTo: self.contentView.centerYAnchor, constant: 10),
            
            activity.centerXAnchor.constraint(equalTo: self.contentView.centerXAnchor),
            activity.centerYAnchor.constraint(equalTo: self.contentView.centerYAnchor)
        ])
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

