//
//  ViewModel.swift
//  SwiftUIPOC
//
//  Created by Venkata Reddy Dubbakula on 26/11/24.
//

import Foundation

class PostsViewModel: ObservableObject {
    @Published var posts: [Post] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String? = nil
    
    func fetchPosts() async {
        isLoading = true
        errorMessage = nil
        
        let url = URL(string: "https://jsonplaceholder.typicode.com/posts")!
        
        do {
            let fetchedPosts: [Post] = try await NetworkManager.shared.fetchData(url: url, type: [Post].self)
            posts = fetchedPosts
        } catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
}
