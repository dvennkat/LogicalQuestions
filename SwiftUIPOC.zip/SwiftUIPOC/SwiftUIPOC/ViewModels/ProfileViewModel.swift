//
//  ProfileViewModel.swift
//  SwiftUIPOC
//
//  Created by Venkata Reddy Dubbakula on 28/11/24.
//

import Foundation
import Combine
import Observation

@Observable class ProfileViewModel: ObservableObject {
    var profiles: [ProfileModel] = []
    var isLoading = false
    var errorMessage: String?

    private var cancellables = Set<AnyCancellable>()
    private let networkManager = NetworkManager.shared
    
    // Function to fetch posts and handle success/error
    func fetchPosts() {
        isLoading = true
        errorMessage = nil
        
        networkManager.fetchSocialProfiles()
            .sink(receiveCompletion: { completion in
                // Handle completion (either success or failure)
                switch completion {
                case .finished:
                    self.isLoading = false
                    break
                case .failure(let error):
                    self.isLoading = false
                    self.errorMessage = error.localizedDescription
                }
            }, receiveValue: { profiles in
                // Handle success (update the posts list)
                self.profiles = profiles
            })
            .store(in: &cancellables) // Store the cancellable to keep the subscription alive
    }
}
