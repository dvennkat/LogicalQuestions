//
//  DetailsScreen.swift
//  SwiftUIPOC
//
//  Created by Venkata Reddy Dubbakula on 28/11/24.
//

import SwiftUI

struct DetailsScreen: View {
    var item: ProfileModel

     var body: some View {
         VStack {
             AsyncImage(url: URL(string: item.imageURL)) { phase in
                 switch phase {
                 case .failure:
                     Image(systemName: "photo")
                         .font(.largeTitle)
                 case .success(let image):
                     image
                         .resizable()
                 default:
                     ProgressView()
                 }
             }
             .frame(width: 250, height: 250)

             Text(item.pokemon)
                 .font(.largeTitle)
                 .padding()
             Text(item.location)
                 .font(.subheadline)
                 .padding()

             Spacer()
         }
         .navigationTitle(item.pokemon)
         .navigationBarTitleDisplayMode(.inline)
     }
}

#Preview {
    DetailsScreen(item: ProfileModel(id: 1, pokemon: "1", location: "", imageURL: ""))
}
