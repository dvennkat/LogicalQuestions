//
//  PostsView.swift
//  SwiftUIPOC
//
//  Created by Venkata Reddy Dubbakula on 26/11/24.
//

import SwiftUI

struct PostsView: View {
    @StateObject private var viewModel = PostsViewModel()
        
    var body: some View {
        NavigationView {
            VStack {
                if viewModel.isLoading {
                    ProgressView("Loading...")
                        .padding()
                } else if let errorMessage = viewModel.errorMessage {
                    Text("Error: \(errorMessage)")
                        .foregroundColor(.red)
                        .padding()
                } else {
                    List(viewModel.posts) { post in
                        VStack(alignment: .leading) {
                            Text(post.title)
                                .font(.headline)
                            Text(post.body)
                                .font(.subheadline)
                                .lineLimit(3)
                        }
                    }
                }
            }
            .onAppear {
                Task {
                    await viewModel.fetchPosts()
                }
            }
            .navigationTitle("Posts")
        }
    }
}

#Preview {
    PostsView()
}
