//
//  ProfileListView.swift
//  SwiftUIPOC
//
//  Created by Venkata Reddy Dubbakula on 28/11/24.
//

import SwiftUI

struct ProfileListView: View {
    private var viewModel = ProfileViewModel()
    
    var body: some View {
        NavigationView {
            VStack {
                if viewModel.isLoading {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle())
                        .padding()
                } else if let errorMessage = viewModel.errorMessage {
                    Text("Error: \(errorMessage)")
                        .foregroundColor(.red)
                        .padding()
                } else {
                    List(viewModel.profiles, id: \.id) { post in
                        NavigationLink {
                            DetailsScreen(item: post)
                        } label: {
                            HStack {
                                AsyncImage(url: URL(string: post.imageURL)) { phase in
                                    switch phase {
                                    case .failure:
                                        Image(systemName: "photo")
                                            .font(.largeTitle)
                                    case .success(let image):
                                        image
                                            .resizable()
                                    default:
                                        ProgressView()
                                    }
                                }
                                .frame(width: 60, height: 60)
                                VStack(alignment: .leading) {
                                    Text(post.pokemon) // Display the title next to the image
                                        .font(.headline) // Customize the font style
                                    Text(post.location)
                                }
                                
                            }
                            .padding()
                        }
                        
                        
                    }
                }
            }
            .navigationTitle("Profiles")
            .onAppear {
                viewModel.fetchPosts()
            }
        }
    }
}


#Preview {
    ProfileListView()
}
