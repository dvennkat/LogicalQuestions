//
//  ContentView.swift
//  SwiftUIPOC
//
//  Created by Venkata Reddy Dubbakula on 26/11/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
                // First Tab
                PostsView()
                    .tabItem {
                        Label("Home", systemImage: "house.fill")
                    }
                // Second Tab
                ProfileListView()
                    .tabItem {
                        Label("Profiles", systemImage: "person.fill")
                    }
            }
    }
}

#Preview {
    ContentView()
}
