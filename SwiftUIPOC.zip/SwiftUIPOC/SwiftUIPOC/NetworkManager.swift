//
//  NetworkManager.swift
//  SwiftUIPOC
//
//  Created by Venkata Reddy Dubbakula on 26/11/24.
//

import Foundation
import Combine

class NetworkManager {
    
    static let shared = NetworkManager()
    
    private init() {}
    
    // A generic function to handle GET requests
    func fetchData<T: Decodable>(url: URL, type: T.Type) async throws -> T {
        let (data, _) = try await URLSession.shared.data(from: url)
        let decoder = JSONDecoder()
        let decodedData = try decoder.decode(T.self, from: data)
        return decodedData
    }
    
    // Method to fetch profiles from a network endpoint
      func fetchSocialProfiles() -> AnyPublisher<[ProfileModel], Error> {
          guard let url = URL(string: "https://dummyapi.online/api/pokemon") else {
              return Fail(error: URLError(.badURL)).eraseToAnyPublisher()
          }

          return URLSession.shared.dataTaskPublisher(for: url)
              .map { data, response in
                  return data
              }
              .decode(type: [ProfileModel].self, decoder: JSONDecoder())
              .receive(on: DispatchQueue.main) // Ensure updates happen on the main thread
              .eraseToAnyPublisher()
      }
}


