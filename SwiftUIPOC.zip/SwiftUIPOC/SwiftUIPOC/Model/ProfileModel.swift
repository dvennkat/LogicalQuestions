//
//  ProfileModel.swift
//  SwiftUIPOC
//
//  Created by Venkata Reddy Dubbakula on 27/11/24.
//

import Foundation

// MARK: - Welcome
struct ProfileModel: Codable {
    let id: Int
    let pokemon: String
    let location: String
    let imageURL: String
    
    enum CodingKeys: String, CodingKey {
        case id, pokemon, location
        case imageURL = "image_url"
    }
}
