//
//  Model.swift
//  SwiftUIPOC
//
//  Created by Venkata Reddy Dubbakula on 26/11/24.
//

import Foundation

struct Post: Identifiable, Codable {
    let id: Int
    let title: String
    let body: String
}
