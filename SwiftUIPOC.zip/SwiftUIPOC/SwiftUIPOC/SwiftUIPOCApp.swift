//
//  SwiftUIPOCApp.swift
//  SwiftUIPOC
//
//  Created by Venkata Reddy Dubbakula on 26/11/24.
//

import SwiftUI

@main
struct SwiftUIPOCApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
