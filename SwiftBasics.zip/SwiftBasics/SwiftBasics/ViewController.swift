//
//  ViewController.swift
//  SwiftBasics
//
//  Created by Venkata Reddy Dubbakula on 09/12/24.
//

import UIKit



class ViewController: UIViewController {
    
    var name = "John"
    var fullname: String = {
        return "name"
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        higherOrder()
        let a = aClass()
        print(a.name)
        let b = bClass()
        print(b)
        print(fullname)
        closurExm(completion: true)
        
        closurExm1 { value in
            print(value)
        }
        
        
    }
    
    func higherOrder() {
        let arr = ["1", "5", "33", "12", "11", "8", "abc", "0"]
        let resultArr = arr.compactMap({Int($0)})
        print(resultArr.reduce(0, { $0 + $1 }))
    }
    
    class bClass {
        private let name = ""
    }
    
    func closurExm(completion: @autoclosure () -> Bool) {
        if completion() {
            print("success")
        } else {
            print("failure")
        }
    }
    
    func closurExm1(completion: (Bool) -> ()) {
        completion(true)
    }

}

class aClass {
    fileprivate let name = ""
}

extension SecondViewController {
    var name1: String {
        return ""
    }
    func myFunction() {
    }
}
