//
//  ViewController.swift
//  LogicalQA
//
//  Created by Venkata Reddy Dubbakula on 02/12/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       // AcsendingOder()
       // removeDuplicates()
       // largestnumberAndDelete()
       // repeatedElements()
       // repeatedLetterInWord()
        
//        let sentence = "Hello, how many times does the letter 'o' appear?"
//        let letterToFind: Character = "o"
//        let occurrences = countOccurrences(of: letterToFind, in: sentence)
//
//        print("The letter '\(letterToFind)' appears \(occurrences) times.")
        
        //multipleofgivenNo()
    }
    
    func AcsendingOder() {
        var arr = [15, 2, 9, 18, 4, 10, 8]
        for value in 0...arr.count - 1 {
            var temp = 0
            for valueTwo in value...arr.count - 1 {
                if arr[value] > arr[valueTwo] {
                    // print("one: \(arr[value]), two \(arr[valueTwo]) ")
                    temp = arr[value]
                    arr[value] = arr[valueTwo]
                    arr[valueTwo] = temp
                }
            }
        }
        print(arr)
    }
    
    func removeDuplicates() {
        let arr = [2, 3, 5, 1, 2, 10, 18, 5]
        var resultArr: [Int] = []
        for value in arr {
            if !resultArr.contains(value) {
                resultArr.append(value)
            }
        }
        print(resultArr)
    }
    
    func largestnumberAndDelete() {
        var arr  = [2, 5, 10, 4, 33, 18, 9, 7, 110, 14, 110]
        var largestNo = 0
        for value in arr {
            if value > largestNo {
                largestNo = value
            }
        }
        print(largestNo)
        if let indexValue = arr.firstIndex(of: largestNo) {
            arr.remove(at: indexValue)
        }
        print(arr)
        
        /// if you want to remove multiple duplicate values
        arr = arr.filter({ $0 != largestNo })
        print(arr)
    }

    func repeatedElements() {
        let arr = [2, 4, 2, 6, 2, 1, 6, 4, 5, 5]
        var resultDic: [Int : Int] = [:]
        for value in arr {
            resultDic[value] = (resultDic[value] ?? 0) + 1
           // if resultDic[value] == nil  {
                //                resultDic[value] =  1
                //            } else {
                //                resultDic[value]! += 1
                //            }
            //}
        }
        print(resultDic)
        
        for (key, value) in resultDic {
            print("key:\(key), value: \(value)")
        }
    }
    
    func repeatedLetterInWord() {
        let name = "dubbakula venkata Reddy"
        var nameDic = [String : Int]()
        for characters in name {
            nameDic[String(characters), default: 0] += 1
        }
        print(nameDic["d"] ?? 0)
        print(nameDic)
    }
    
    func countOccurrences(of letter: Character, in sentence: String) -> Int {
        var count = 0
        for char in sentence {
            if char == letter {
                count += 1
            }
        }
        return count
    }
    

}

